<<<<<<< HEAD
# IOT-Project


The project focuses on monitoring and controlling industrial systems in real time using IoT technology. It captures data from sensors, processes it on a server, and displays it on a responsive dashboard. It also allows remote control of connected devices.
=======
# IoT
>>>>>>> 12e863a (iot)
